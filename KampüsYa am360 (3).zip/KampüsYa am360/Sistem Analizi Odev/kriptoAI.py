from binance.client import Client
from binance.streams import ThreadedWebsocketManager
import pandas as pd
import ta
import numpy as np
import telegram

# Binance API bilgilerin (public/private key zorunlu değil sadece data için)
api_key = 'API_KEYİNİZ'
api_secret = 'API_SECRETİNİZ'

client = Client(api_key, api_secret)

# Telegram Bot ayarları (isteğe bağlı)
telegram_token = 'TELEGRAM_BOT_TOKEN'
chat_id = 'CHAT_IDİNİZ'
bot = telegram.Bot(token=telegram_token)

symbol = 'btcusdt'
interval = '1m'  # 1 dakikalık veri

# Veri çerçevesi (DataFrame) oluştur
df = pd.DataFrame(columns=['open_time', 'open', 'high', 'low', 'close', 'volume'])

def send_telegram_message(message):
    bot.send_message(chat_id=chat_id, text=message)

def process_message(msg):
    global df
    
    if msg['e'] != 'kline':
        return
    
    kline = msg['k']
    is_candle_closed = kline['x']
    close = float(kline['c'])
    open_time = pd.to_datetime(kline['t'], unit='ms')
    
    if is_candle_closed:
        # Yeni mum kapanınca DataFrame'e ekle
        new_row = {'open_time': open_time,
                   'open': float(kline['o']),
                   'high': float(kline['h']),
                   'low': float(kline['l']),
                   'close': close,
                   'volume': float(kline['v'])}
        df = df.append(new_row, ignore_index=True)
        
        if len(df) > 20:  # Yeterli veri varsa analiz yap
            df['rsi'] = ta.momentum.rsi(df['close'], window=14)
            df['ema_fast'] = ta.trend.ema_indicator(df['close'], window=9)
            df['ema_slow'] = ta.trend.ema_indicator(df['close'], window=21)
            
            last_rsi = df['rsi'].iloc[-1]
            ema_fast = df['ema_fast'].iloc[-1]
            ema_slow = df['ema_slow'].iloc[-1]
            
            # Basit sinyal örneği
            if last_rsi < 30 and ema_fast > ema_slow:
                print(f"{open_time} AL sinyali verildi! RSI: {last_rsi:.2f}")
                send_telegram_message(f"{open_time} AL sinyali! RSI: {last_rsi:.2f}")
            elif last_rsi > 70 and ema_fast < ema_slow:
                print(f"{open_time} SAT sinyali verildi! RSI: {last_rsi:.2f}")
                send_telegram_message(f"{open_time} SAT sinyali! RSI: {last_rsi:.2f}")

# WebSocket Manager başlat
twm = ThreadedWebsocketManager(api_key=api_key, api_secret=api_secret)
twm.start()

# Stream başlat (ör: 1 dakika mumları için)
twm.start_kline_socket(callback=process_message, symbol=symbol, interval=interval)

print("Binance Futures sinyal botu başladı...")

# Programı açık tut
import time
while True:
    time.sleep(1)
